package medium;

import common.TreeNode;

public class P99 {
    public void recoverTree(TreeNode root) {

    }
}
