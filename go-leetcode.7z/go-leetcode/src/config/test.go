package main

import . "fmt"

type Hero struct {
	name  string
	ad    int
	level int
}

func (h *Hero) Name() string {
	return h.name
}

func (h *Hero) SetName(name string) {
	h.name = name
}

func (h *Hero) Ad() int {
	return h.ad
}

func (h *Hero) SetAd(ad int) {
	h.ad = ad
}

func (h *Hero) Level() int {
	return h.level
}

func (h *Hero) SetLevel(level int) {
	h.level = level
}
func (h Hero) attack() {
	Println(h.name, "   attack")
}

// 继承
type Superman struct {
	Hero
	fly string
}

func main() {
	hero := Hero{"batman", 100, 99}
	Println(hero)
	hero.SetLevel(999)
	Println(hero)
	hero.attack()
	klake := Superman{Hero{"superman", 100, 99}, "flying"}
	klake.attack()
}
