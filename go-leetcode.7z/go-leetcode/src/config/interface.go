package main

import "fmt"

// Animal 多态
type Animal interface {
	GetName() string
	GetKind() string
	run()
}

type Cat struct {
	name string
}

func (cat *Cat) GetName() string {
	return "Tiny Cat"
}

func (cat *Cat) GetKind() string {
	return "I`m cat"
}

func (cat *Cat) run() {
	fmt.Println(cat.name, "is RUN")
}

type Dog struct {
	name string
}

func (dog *Dog) GetName() string {
	return "Tiny Dog"
}

func (dog *Dog) GetKind() string {
	return "I`m dog"
}

func (dog *Dog) run() {
	fmt.Println(dog.name, "is RUN")
}
func showAnimal(animal Animal) {
	fmt.Println(animal)
}

// 万能类型interface{}
func noneInterface(arg interface{}) {
	fmt.Println("none", arg)

	//断言
	value, ok := arg.(string)
	if ok {
		fmt.Println("arg is string")
	} else {
		fmt.Println("arg is not string")
		fmt.Printf("arg is %T\n", value)
	}
}

func main() {
	cat := Cat{"Tom"}
	cat.run()
	showAnimal(&cat)
	dog := Dog{"Tidy"}
	dog.run()
	showAnimal(&dog)
	noneInterface(3.14)
	noneInterface("hello")
}
