package main

import (
	"fmt"
	"sync"
)

func goRun() {
	defer fmt.Println("func goRun end")
	for i := 0; i < 10; i++ {
		fmt.Printf("func run %v\n", i)
	}
	wg.Done()
}

var wg sync.WaitGroup

func main() {
	wg.Add(1)
	go goRun()
	for i := 0; i < 10; i++ {
		fmt.Printf("main run %v\n", i)
	}
	wg.Wait()

	//runtime.Goexit()
}
