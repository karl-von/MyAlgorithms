package main

import (
	"fmt"
)

func main() {
	//c := make(chan string)
	//go func() {
	//	defer fmt.Println("func go end")
	//	for i := 0; i < 100; i++ {
	//		fmt.Printf("go func run %v\n", i)
	//	}
	//	c <- "end end end"
	//}()
	//num := <-c
	//fmt.Printf("%v\n", num)
	//fmt.Println()
	//close(c)

	c1 := make(chan int, 2)
	go func() {
		defer fmt.Println("new func go end")
		for i := 0; i < 5; i++ {
			fmt.Printf("new go func run %v\n", i)
			c1 <- i
		}
	}()
	//time.Sleep(2 * time.Second)
	for i := 0; i < 5; i++ {
		num := <-c1
		fmt.Println("num = ", num)
	}
	//time.Sleep(2 * time.Second)
	fmt.Println("end")
}
