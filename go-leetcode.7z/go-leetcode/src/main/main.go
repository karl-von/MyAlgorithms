package main

import "fmt"

func main() {
	m := make(map[int]int, 1)
	fmt.Println(m[1])
}
