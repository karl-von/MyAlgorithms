package tool

type TreeNode struct {
	Val   int
	Left  *TreeNode
	Right *TreeNode
}
