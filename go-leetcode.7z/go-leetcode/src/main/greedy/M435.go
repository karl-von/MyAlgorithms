package greedy

import "sort"

func eraseOverlapIntervals(intervals [][]int) (res int) {

	sort.Slice(intervals, func(i, j int) bool {
		return intervals[i][0] < intervals[j][0]
	})
	for i := 0; i < len(intervals); i++ {

	}

	return res
}
