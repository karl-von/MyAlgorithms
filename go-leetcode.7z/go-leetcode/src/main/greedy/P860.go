package greedy

func lemonadeChange(bills []int) bool {
	b5, b10, b20 := 0, 0, 0
	for i := 0; i < len(bills); i++ {
		b := bills[i]
		if b == 5 {
			b5++
		} else if b == 10 {
			if b5 >= 1 {
				b5--
				b10++
			} else {
				return false
			}
		} else {
			if b10 >= 1 && b5 >= 1 {
				b10--
				b5--
				b20++
			} else if b5 >= 3 {
				b5 -= 3
				b20++
			} else {
				return false
			}
		}
	}
	return true
	//m := make(map[int]int, 0)
	//m[5], m[10], m[20] = 0, 0, 0
	//for i := 0; i < len(bills); i++ {
	//	b := bills[i]
	//	if b == 5 {
	//		m[5] = m[5] + 1
	//	} else if b == 10 {
	//		if m[5] >= 1 {
	//			m[5]--
	//			m[10]++
	//		} else {
	//			return false
	//		}
	//	} else {
	//		if m[10] >= 1 && m[5] >= 1 {
	//			m[10]--
	//			m[5]--
	//			m[20]++
	//		} else if m[5] >= 3 {
	//			m[5] -= 3
	//			m[20]++
	//		} else {
	//			return false
	//		}
	//	}
	//}
	//return true
}
