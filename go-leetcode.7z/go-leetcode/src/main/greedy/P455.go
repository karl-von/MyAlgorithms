package greedy

import "sort"

func findContentChildren(g []int, s []int) (res int) {
	j := len(g) - 1
	sort.Ints(g)
	sort.Ints(s)
	for i := len(s) - 1; i >= 0 && j >= 0; i++ {
		if s[i] >= g[j] {
			res++
			j--
		} else {
			i++
			j--
		}
	}
	return res
}
