package greedy

func canJump(nums []int) bool {
	l := len(nums) - 1
	step := 0
	var max = func(x int, y int) int {
		if x >= y {
			return x
		} else {
			return y
		}
	}
	for i := 0; i <= step; i++ {
		num := nums[i]
		if step+num >= l {
			return true
		}
		step = max(step, i+nums[i])
	}
	return false
}
