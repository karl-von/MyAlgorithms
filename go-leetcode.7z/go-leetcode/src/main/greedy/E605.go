package greedy

func canPlaceFlowers(flowerbed []int, n int) bool {
	l := len(flowerbed)
	for i := 0; i < l && n > 0; i++ {
		if flowerbed[i] == 1 {
			i++
		} else {
			if (i == 0 || flowerbed[i-1] == 0) && (i == l-1 || flowerbed[i+1] == 0) {
				n--
				i++
			}
		}
	}
	return n == 0
}

//	l := len(flowerbed)
//	for i := 0; i < l; i++ {
//		if n ==0{
//			return true
//		}
//		if flowerbed[i] == 1 {
//			continue
//		} else {
//			if i-1 >= 0 && i+1 < l {
//				if flowerbed[i-1]+flowerbed[i+1] == 0 {
//					flowerbed[i] = 1
//					n--
//				}
//			} else if i-1 < 0 && i+1 >= l {
//				flowerbed[i] = 1
//				n--
//			} else if i-1 < 0 && flowerbed[i+1] == 0 {
//				flowerbed[i] = 1
//				n--
//			} else if i+1 == l && flowerbed[i-1] == 0 {
//				flowerbed[i] = 1
//				n--
//			}
//		}
//	}
//	return n == 0
//}
