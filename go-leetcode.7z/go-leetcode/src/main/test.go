package main

import (
	"fmt"
)

const (
	a = iota
	b
	c
	d
	e
)

var (
	f = 10
	g = 20
)

func errorDemo(i int) {
	//定义10个元素的数组
	var arr [10]int
	//错误拦截要在产生错误前设置
	defer func(i int) {
		//设置recover拦截错误信息
		err := recover()
		//产生panic异常  打印错误信息
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println("not err")
		}
	}(i)
	//根据函数参数为数组元素赋值
	//如果i的值超过数组下标 会报错误：数组下标越界
	arr[i] = 10

}
func swap(f *int, g *int) {
	temp := *g
	*g = *f
	*f = temp

}
func hello(str1 string, str2 string) (string, string) {
	return str1 + str2, "thank you!"
}

func sliceTest() {
	arr := []int{1, 2, 3, 4}
	totalArr := arr[:]
	copyArr := make([]int, 4, 10)
	copy(copyArr, arr)
	copyArr = append(copyArr, 5, 6, 7, 8, 9)
	twoArr := arr[:2]
	fourArr := arr[0:4] //包括起始不包括末尾
	fmt.Println(totalArr, "\n", copyArr, "\n", twoArr, "\n",
		fourArr, "\n", cap(copyArr))
}
func mapTest() {
	map1 := make(map[string]string)
	map1["hello"] = "world"
	//map2 := map[string]string{
	//	"你好": "世界",
	//}

}
func main() {
	s, s2 := hello("hello", "golang")
	println(s, " ", s2)
	println(a, " ", b, " ", c, " ", d, " ", e)
	swap(&f, &g)
	println(f, " ", g)
	errorDemo(9)
	println("run")
	sliceTest()
	println("---------------------------")
	str := "123456"
	println(str[0:3])

}
