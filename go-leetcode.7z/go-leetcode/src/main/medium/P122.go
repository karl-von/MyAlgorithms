package medium

func maxProfit(prices []int) int {
	temp := prices[0]
	sum := 0
	for i := 0; i < len(prices); i++ {
		current := prices[i]
		if current > temp {
			sum += current - temp
		}
		temp = current
	}
	return sum
}
