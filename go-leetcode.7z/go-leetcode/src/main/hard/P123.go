package hard

func maxProfit(prices []int) int {
	temp := prices[0]
	twoV := newTwoV()
	isTwoBuy := false
	for i := 0; i < len(prices); i++ {
		current := prices[i]
		//即使弱于他人，我的心也绝不会屈服
		if current > temp {
			twoV.add(current - temp)
		} else if current == temp {
			continue
		} else {
			isTwoBuy = true
			temp = current
		}
	}
	if isTwoBuy {
		return twoV.x + twoV.y
	} else {
		return twoV.y
	}
}

type twoV struct {
	x int
	y int
}

func (v *twoV) add(i int) {
	if i > v.x {
		v.x = i
		v.max()
	}
}
func (v *twoV) max() {
	if v.x > v.y {
		temp := v.y
		v.y = v.x
		v.x = temp
	}
}
func newTwoV() twoV {
	return twoV{
		x: 0,
		y: 0,
	}
}
