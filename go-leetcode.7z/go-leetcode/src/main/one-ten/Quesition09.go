package one_ten

import (
	"strconv"
	"strings"
)

func isPalindrome(x int) bool {
	var s = strconv.Itoa(x)
	split := strings.Split(s, "")
	if x < 0 {
		return false
	}
	length := len(split) - 1
	for index := range split {
		if split[index] == split[length-index] {
			continue
		} else {
			if index == length - index {
				continue
			} else {
				return false
			}
		}
	}
	return true
}
