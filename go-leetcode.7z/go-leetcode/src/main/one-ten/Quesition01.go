package one_ten

func twoSum(nums []int, target int) []int {
	//var result []int
	result := make([]int, 2)
	for i := 0; i < len(nums); i++ {
		for j := 1; j < len(nums)-1; j++ {
			if nums[i]+nums[j] == target {
				result[0] = i
				result[1] = j
				return result
			}
		}
	}
	return result
}
