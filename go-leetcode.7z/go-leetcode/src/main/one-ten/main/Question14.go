package main

import "strings"

func longestCommonPrefix(strs []string) string {
	index := 0
	var isPrefix bool
	if strs[0] == "" {
		return ""
	}
	for {
		prefix := strings.Fields(strs[0])[0]
		index, isPrefix = testPrefix(strs, prefix[0:index], index)
		if !isPrefix || index >= len(strs[0]) {
			str := strs[0]
			return str[0 : index-1]
		}
	}

}

func testPrefix(strs []string, prefix string, index int) (int, bool) {
	for _, s := range strs {
		if !strings.HasPrefix(s, prefix) {
			return index, false
		}
	}
	strings.Index(strs[0], prefix)
	return index + 1, true
}
func main() {
	strs := []string{
		"a",
	}
	println(longestCommonPrefix(strs))

}
