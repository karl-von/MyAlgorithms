package easy

func majorityElement(nums []int) int {
	big := 0
	m := make(map[int]int)
	for i := 0; i < len(nums); i++ {
		_, ok := m[nums[i]]
		if ok {
			m[nums[i]]++
		} else {
			m[nums[i]] = 1
		}
		if m[nums[i]] > m[big] {
			big = nums[i]
		}
	}
	return big
}
