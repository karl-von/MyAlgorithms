package easy

import . "../tool"

func postorderTraversal(root *TreeNode) []int {
	result := make([]int, 0)
	result = dfs(root, result)
	return result
}
func dfs(root *TreeNode, result []int) []int {
	if root == nil {
		return result
	}
	dfs(root.Left, result)
	dfs(root.Right, result)
	result = append(result, root.Val)
	return result
}
