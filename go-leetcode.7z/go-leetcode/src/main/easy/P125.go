package easy

import (
	"strings"
)

func isPalindrome(s string) bool {
	length := len(s)

	var newS string
	for i := 0; i < length; i++ {
		if isalnum(s[i]) {
			newS += string(s[i])
		}
	}
	newS = strings.ToLower(newS)
	j := len(newS) - 1
	for i := 0; i < len(newS); i++ {
		if i == j {
			break
		}
		if newS[i] != newS[j] {
			return false
		}
		j--
	}
	return true
}
func isalnum(ch byte) bool {
	return (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')
}
