package easy

func generate(numRows int) [][]int {
	result := make([][]int, 0)
	for i := 0; i < numRows; i++ {
		tiny := make([]int, 0)
		for j := 0; j < i+1; j++ {
			if j == 0 || j == i {
				tiny = append(tiny, 1)
			} else {
				tiny = append(tiny, result[i-1][j-1]+result[i-1][j])
			}

		}
		result = append(result, tiny)
	}

	return result
}
