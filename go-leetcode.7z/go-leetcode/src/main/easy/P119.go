package easy

func getRow(rowIndex int) []int {
	result := make([]int, 0)
	for i := 0; i < rowIndex; i++ {
		front := make([]int, 0)
		for j := 0; j < i+1; j++ {
			if j == 0 || j == i {
				front = append(front, 1)
			} else {
				front = append(front, result[j-1]+result[j])
			}
		}
		if i != rowIndex-1 {
			result = front
		}
	}
	return result
}
