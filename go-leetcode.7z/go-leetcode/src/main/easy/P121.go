package easy

func maxProfit(prices []int) int {
	var max int
	var min int = prices[0]
	for i := 0; i < len(prices); i++ {
		temp := prices[i]
		if temp < min {
			min = temp
		} else {
			max = big(max, temp-min)
		}
	}
	return max
}
func min(x int, y int) int {
	if x <= y {
		return x
	} else {
		return y
	}
}

//		var money int
//		len := len(prices)
//		low := prices[0]
//		for i := 0; i < len-1; i++ {
//			buy := prices[i]
//			if buy >= low && i != 0 {
//				continue
//			} else {
//				low = buy
//			}
//			for j := i + 1; j < len; j++ {
//				if prices[j] <= buy {
//					continue
//				} else {
//					money = big(money, prices[j]-buy)
//				}
//			}
//		}
//		return money
//	}
func big(x int, y int) int {
	if x >= y {
		return x
	} else {
		return y
	}
}
