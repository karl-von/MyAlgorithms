package easy

import . "../tool"

func isSymmetric(root *TreeNode) bool {
	if root.Right == nil && root.Left == nil {
		return true
	} else if root.Right == nil || root.Left == nil {
		return false
	}
	return isSymmetric1(root.Left, root.Right)
}
func isSymmetric1(left *TreeNode, right *TreeNode) bool {
	if right == nil && left == nil {
		return true
	} else if right == nil || left == nil {
		return false
	} else if right.Val != left.Val {
		return false
	} else if !isSymmetric1(right.Left, left.Right) {
		return false
	} else if !isSymmetric1(left.Left, right.Right) {
		return false
	} else {
		return true
	}
}
