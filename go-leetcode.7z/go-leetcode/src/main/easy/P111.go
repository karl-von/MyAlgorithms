package easy

import . "../tool"

func minDepth(root *TreeNode) int {
	return minDepth1(root, 0)
}
func minDepth1(root *TreeNode, sum int) int {
	if root.Left == nil && root.Right == nil {
		return sum
	}
	sum++
	if root.Left != nil && root.Right != nil {
		return whoMin(minDepth1(root.Right, sum), minDepth1(root.Left, sum))

	} else if root.Right != nil {
		return minDepth1(root.Right, sum)
	} else {
		return minDepth1(root.Left, sum)
	}

}
func whoMin(l int, r int) int {
	if l <= r {
		return l
	} else {
		return r
	}
}
