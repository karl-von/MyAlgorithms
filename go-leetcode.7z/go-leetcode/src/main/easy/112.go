package easy

import . "../tool"

func hasPathSum(root *TreeNode, targetSum int) bool {
	return hasPathSum1(root, targetSum, root.Val)
}
func hasPathSum1(root *TreeNode, targetSum int, sum int) bool {
	if root == nil {
		return false
	}
	sum += root.Val
	if root.Left == nil && root.Right == nil {
		return sum == targetSum
	}
	return hasPathSum1(root.Left, targetSum, sum) || hasPathSum1(root.Right, targetSum, sum)
}
