package easy

type MinStack struct {
	l []int
	m MinList
}
type MinList struct {
	ls []int
}

func (l *MinList) add(i int) {
	length := len(l.ls)
	if length == 0 {
		l.ls = append(l.ls, i)
	}
	if l.ls[length-1] > i {
		temp := l.ls[length-1]
		l.ls[length-1] = i
		l.ls = append(l.ls, temp)
	} else {
		l.ls = append(l.ls, i)
	}
}

/** initialize your data structure here. */
func Constructor() MinStack {
	return MinStack{
		make([]int, 0),
		MinList{ls: make([]int, 0)},
	}
}

func (this *MinStack) Push(x int) {
	this.l = append(this.l, x)
	this.m.add(x)
}

func (this *MinStack) Pop() {
	this.l
}

func (this *MinStack) Top() int {

}

func (this *MinStack) Min() int {

}
