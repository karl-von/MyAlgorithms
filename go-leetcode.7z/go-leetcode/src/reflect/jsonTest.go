package main

import (
	"encoding/json"
	"fmt"
)

type Movie struct {
	Name  string   `json:"name"`
	Time  int      `json:"time"`
	Actor []string `json:"actor"`
	Lx    string   `json:"types"`
}

func main() {
	movie := Movie{
		"让子弹飞",
		120,
		[]string{"姜文", "周润发", "葛优"},
		"喜剧",
	}
	result, err := json.Marshal(movie)

	if err != nil {
		fmt.Println("json error")
		return
	}

	fmt.Printf("JSON = %s\n", result)

	newMovie := Movie{}
	err1 := json.Unmarshal(result, &newMovie)
	if err1 != nil {
		return
	} else {
		fmt.Println(newMovie)
	}
}
