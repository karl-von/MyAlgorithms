package main

import (
	"fmt"
	"reflect"
)

type Human struct {
	Name string `info:"myName" json:"name"`
	Id   int
	Age  int
}

func (h Human) GetName() string {
	return h.Name
}
func reflectCommon(input interface{}) {
	inputType := reflect.TypeOf(input)
	inputValue := reflect.ValueOf(input)
	fmt.Printf("type:%v      value:%v\n", inputType, inputValue)
}

func reflectFunc(input interface{}) {
	inputType := reflect.TypeOf(input).Elem()
	inputValue := reflect.ValueOf(input).Elem()
	fmt.Printf("type:%v      value:%v\n", inputType, inputValue)
	fmt.Printf("typeName:%v      value:%v\n", inputType.Name(), inputValue)
	for i := 0; i < inputType.NumField(); i++ {
		field := inputType.Field(i)
		value := inputValue.Field(i).Interface()
		fmt.Println("filed: ", field.Name, field.Type, "     value: ", value)
		fmt.Println(field.Tag)
	}
	for i := 0; i < inputType.NumMethod(); i++ {
		method := inputType.Method(i)
		fmt.Println(method, "   ", method.Name, method.Type)
	}
}

// panic: reflect.Value.Interface: cannot return value obtained from unexported fie
// ld or method
func main() {
	man := Human{"karl", 514, 23}
	reflectFunc(&man)
	reflectCommon(3.14)
}
